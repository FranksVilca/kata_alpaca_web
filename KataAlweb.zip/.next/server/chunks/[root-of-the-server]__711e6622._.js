module.exports=[70406,(e,i,a)=>{i.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},10318,e=>{"use strict";var i=e.i(26747),a=e.i(90406),t=e.i(44898),o=e.i(62950),d=e.i(88712);async function r(e,i){if("POST"!==e.method)return i.status(405).end();let{nombre:a,apellidoPaterno:t,apellidoMaterno:o,tipoDocumento:r,numeroDocumento:l,correo:s,telefono:n,pais:c,direccion:p,tipoProducto:v,monto:f,descripcion:u,motivo:x,detalle:g,comprobante:m}=e.body,b=d.default.createTransport({service:"Gmail",auth:{user:process.env.EMAIL_USER_BOOK,pass:process.env.EMAIL_PASS_BOOK}});try{return await b.sendMail({from:process.env.EMAIL_USER,replyTo:s,to:process.env.EMAIL_USER,subject:`📋 ${"reclamo"===x?"RECLAMO":"QUEJA"} - ${a} ${t}`,html:`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
              .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
              .logo-section { background: white; padding: 20px; text-align: center; border-bottom: 3px solid #575151; }
              .logo-section img { max-width: 150px; height: auto; }
              .header { background: linear-gradient(135deg, #F2F2D0 0%, #F2F2D0 100%); color: #575151; padding: 30px; text-align: center; }
              .header h1 { margin: 0; font-size: 24px; }
              .content { background: #f9f9f9; padding: 30px; }
              .section-title { background: #FF8112; color: white; padding: 10px 15px; margin: 20px 0 15px 0; border-radius: 5px; font-weight: bold; }
              .field { background: white; margin: 10px 0; padding: 15px; border-radius: 8px; border-left: 4px solid #575151; }
              .field-label { color: #FF8112; font-weight: bold; font-size: 12px; text-transform: uppercase; margin-bottom: 5px; }
              .field-value { color: #333; font-size: 16px; word-break: break-word; }
              .message-box { background: white; padding: 20px; border-radius: 8px; margin-top: 15px; border: 2px solid #575151; }
              .footer { text-align: center; padding: 20px; background: #333; color: white; }
              .footer a { color: #FAF5E8; text-decoration: none; }
              .badge { display: inline-block; background: ${"reclamo"===x?"#dc3545":"#ffc107"}; color: white; padding: 5px 15px; border-radius: 20px; font-size: 12px; margin-top: 10px; font-weight: bold; }
              .alert-box { background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 15px 0; border-radius: 5px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="logo-section">
                <img src="https://www.kataalpaca.com/en/img/logo/logo-kata-alpaca.png" alt="KATA ALPACA Logo">
              </div>
              
              <div class="header">
                <h1>📋 Libro de Reclamaciones</h1>
                <div class="badge">${"reclamo"===x?"RECLAMO":"QUEJA"}</div>
              </div>
              
              <div class="content">
                <div class="section-title">👤 DATOS DEL CONSUMIDOR</div>
                
                <div class="field">
                  <div class="field-label">Nombre Completo</div>
                  <div class="field-value">${a} ${t} ${o}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">Documento de Identidad</div>
                  <div class="field-value">${r.toUpperCase()}: ${l}</div>
                </div>

                <div class="section-title">📞 DATOS DE CONTACTO</div>
                
                <div class="field">
                  <div class="field-label">📧 Correo Electr\xf3nico</div>
                  <div class="field-value"><a href="mailto:${s}" style="color: #575151; text-decoration: none;">${s}</a></div>
                </div>
                
                <div class="field">
                  <div class="field-label">📱 Tel\xe9fono</div>
                  <div class="field-value"><a href="tel:${n}" style="color: #575151; text-decoration: none;">${n}</a></div>
                </div>
                
                <div class="field">
                  <div class="field-label">🌍 Pa\xeds</div>
                  <div class="field-value">${c}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">📍 Direcci\xf3n</div>
                  <div class="field-value">${p}</div>
                </div>

                <div class="section-title">🛍️ IDENTIFICACI\xd3N DEL PRODUCTO/SERVICIO</div>
                
                <div class="field">
                  <div class="field-label">Tipo</div>
                  <div class="field-value">${"producto"===v?"Producto":"Servicio"}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">💰 Monto</div>
                  <div class="field-value">${f}</div>
                </div>
                
                <div class="message-box">
                  <div class="field-label">📝 Descripci\xf3n del Producto/Servicio</div>
                  <div class="field-value" style="margin-top: 10px; white-space: pre-wrap;">${u||"No proporcionada"}</div>
                </div>

                <div class="section-title">⚠️ DETALLE DEL ${"reclamo"===x?"RECLAMO":"QUEJA"}</div>
                
                <div class="alert-box">
                  <strong>${"reclamo"===x?"🔴 RECLAMO":"🟡 QUEJA"}:</strong>
                  ${"reclamo"===x?"Disconformidad relacionada a los productos o servicios":"Disconformidad no relacionada a los productos o servicios; o, malestar o descontento respecto a la atención al público"}
                </div>
                
                <div class="message-box">
                  <div class="field-label">Detalle Completo</div>
                  <div class="field-value" style="margin-top: 10px; white-space: pre-wrap;">${g}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">🧾 Comprobante de Pago</div>
                  <div class="field-value">${m}</div>
                </div>
                
                <div style="text-align: center; margin-top: 20px; padding: 15px; background: white; border-radius: 8px;">
                  <p style="color: #666; font-size: 12px; margin: 5px 0;">Recibido el ${new Date().toLocaleString("es-PE",{dateStyle:"full",timeStyle:"short"})}</p>
                  <p style="color: #999; font-size: 11px; margin: 5px 0;">La empresa dar\xe1 respuesta en un plazo m\xe1ximo de 30 d\xedas calendario</p>
                </div>
              </div>
              
              <div class="footer">
                <p style="margin: 5px 0;"><strong>KATA ALPACA</strong></p>
                <p style="margin: 5px 0; font-size: 12px;">Libro de Reclamaciones</p>
                <p style="margin: 5px 0; font-size: 12px;">
                  <a href="mailto:${process.env.EMAIL_USER}">${process.env.EMAIL_USER}</a>
                </p>
              </div>
            </div>
          </body>
        </html>
      `,text:`
        KATA ALPACA - LIBRO DE RECLAMACIONES
        ${"reclamo"===x?"RECLAMO":"QUEJA"}
        
        === DATOS DEL CONSUMIDOR ===
        Nombre: ${a} ${t} ${o}
        Documento: ${r.toUpperCase()} - ${l}
        
        === DATOS DE CONTACTO ===
        Email: ${s}
        Tel\xe9fono: ${n}
        Pa\xeds: ${c}
        Direcci\xf3n: ${p}
        
        === IDENTIFICACI\xd3N DEL PRODUCTO/SERVICIO ===
        Tipo: ${"producto"===v?"Producto":"Servicio"}
        Monto: ${f}
        Descripci\xf3n: ${u||"No proporcionada"}
        
        === DETALLE DEL ${"reclamo"===x?"RECLAMO":"QUEJA"} ===
        ${g}
        
        Comprobante: ${m}
        
        Recibido el ${new Date().toLocaleString("es-PE")}
      `}),i.status(200).json({success:!0})}catch(e){return console.error("Error al enviar correo:",e),i.status(500).json({error:"Error al enviar el correo"})}}e.s(["default",()=>r],37446);var l=e.i(37446),s=e.i(7031),n=e.i(81927),c=e.i(46432);let p=(0,o.hoist)(l,"default"),v=(0,o.hoist)(l,"config"),f=new t.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/complaintBook",pathname:"/api/complaintBook",bundlePath:"",filename:""},userland:l,distDir:".next",relativeProjectDir:""});async function u(e,a,t){f.isDev&&(0,c.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let o="/api/complaintBook";o=o.replace(/\/index$/,"")||"/";let d=await f.prepare(e,a,{srcPage:o});if(!d){a.statusCode=400,a.end("Bad Request"),null==t.waitUntil||t.waitUntil.call(t,Promise.resolve());return}let{query:r,params:l,prerenderManifest:p,routerServerContext:v}=d;try{let i=e.method||"GET",t=(0,s.getTracer)(),d=t.getActiveScopeSpan(),c=f.instrumentationOnRequestError.bind(f),u=async d=>f.render(e,a,{query:{...r,...l},params:l,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:p.preview,propagateError:!1,dev:f.isDev,page:"/api/complaintBook",internalRevalidate:null==v?void 0:v.revalidate,onError:(...i)=>c(e,...i)}).finally(()=>{if(!d)return;d.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=t.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==n.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=e.get("next.route");if(r){let e=`${i} ${r}`;d.setAttributes({"next.route":r,"http.route":r,"next.span_name":e}),d.updateName(e)}else d.updateName(`${i} ${o}`)});d?await u(d):await t.withPropagatedContext(e.headers,()=>t.trace(n.BaseServerSpan.handleRequest,{spanName:`${i} ${o}`,kind:s.SpanKind.SERVER,attributes:{"http.method":i,"http.target":e.url}},u))}catch(e){if(f.isDev)throw e;(0,i.sendError)(a,500,"Internal Server Error")}finally{null==t.waitUntil||t.waitUntil.call(t,Promise.resolve())}}e.s(["config",0,v,"default",0,p,"handler",()=>u],10318)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__711e6622._.js.map
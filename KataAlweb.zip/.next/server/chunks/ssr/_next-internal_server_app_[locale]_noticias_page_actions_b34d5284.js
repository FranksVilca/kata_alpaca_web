module.exports=[6339,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_noticias_page_actions_b34d5284.js.map
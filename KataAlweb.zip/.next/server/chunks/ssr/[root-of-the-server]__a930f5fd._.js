module.exports=[21598,a=>{a.v({className:"aboreto_b82546a8-module__Uzqmja__className"})},67506,a=>{a.v({className:"jura_3df80fad-module__tg9xUa__className"})},3773,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(21598);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(67506);let h={className:g.default.className,style:{fontFamily:"'Jura', 'Jura Fallback'",fontStyle:"normal"}};null!=g.default.variable&&(h.variable=g.default.variable);var i=a.i(15925);function j(){let a=(0,i.useTranslations)("Process.w2");return(0,b.jsx)("section",{className:"w-full py-6 md:py-20 bg-white",children:(0,b.jsxs)("div",{className:"w-full px-0",children:[(0,b.jsxs)(d.motion.div,{className:"flex items-center gap-4 mb-4 px-0 md:hidden",children:[(0,b.jsx)("div",{className:"flex-1 h-px bg-gray-300"}),(0,b.jsx)("h2",{className:`
              ${f.className}
              text-[16px] md:text-2xl 
              font-thin
              text-[#C85A3F]
              text-center
              tracking-tighter
              whitespace-nowrap
              drop-shadow-[0_8px_2px_rgba(0,0,0,0.3)]
            `,children:a("title")}),(0,b.jsx)("div",{className:"flex-1 h-px bg-gray-300"})]}),(0,b.jsx)(d.motion.h2,{className:`
            ${f.className}
            hidden md:block
            md:text-[3.5vw]
            md:font-thin
            md:tracking-[0.01rem]
            md:text-[#C85A3F]
            md:mb-8
            md:text-center
            md:drop-shadow-[0_4px_1px_rgba(0,0,0,0.2)]  

          `,children:a("title")}),(0,b.jsx)(d.motion.p,{className:`
            ${h.className}
            block md:hidden
            text-[14px]
            font-normal
            text-[#000000]
            text-center
            px-4
            mb-10
          `,children:a("text")}),(0,b.jsxs)("div",{className:"   relative    h-[280px]    mb-2    md:flex md:flex-col md:gap-6    md:h-auto md:mb-12 md:max-w-full   ",children:[(0,b.jsxs)(d.motion.div,{className:"   absolute    left-0    w-[70%] h-[150px]    z-10    md:mt-0   md:relative md:w-[78%] md:h-[300px]   ",children:[(0,b.jsx)(c.default,{src:"/procesos/1img.webp",alt:"Proceso de diseño",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/40"})]}),(0,b.jsxs)(d.motion.div,{className:"   absolute    bottom-0 right-0    w-[70%] h-[120px]    z-20    drop-shadow-[-8px_-8px_0px_rgba(255,255,255,1)]   md:relative md:self-end md:w-[78%] md:h-[300px] md:drop-shadow-none   ",children:[(0,b.jsx)(c.default,{src:"/procesos/2img.webp",alt:"Telas y productos",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/40"})]})]}),(0,b.jsx)(d.motion.p,{className:`
            ${h.className}
            hidden md:block
            md:text-4xl
            md:font-medium
            md:text-[#C85A3F]
            text-center
            md:px-0
            md:mt-12 md:max-w-5xl md:mx-auto
            md:drop-shadow-[0_3px_0px_rgba(0,0,0,0.3)]
          `,children:a("text")})]})})}a.s(["default",()=>j],3773)},4530,a=>{a.v({className:"aboreto_a56cc94e-module__uuxirW__className"})},43235,a=>{a.v({className:"raleway_7200eb3a-module__UZ8Doq__className"})},43774,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(4530);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(43235);let h={className:g.default.className,style:{fontFamily:"'Raleway', 'Raleway Fallback'",fontStyle:"normal"}};null!=g.default.variable&&(h.variable=g.default.variable);var i=a.i(15925);function j(){let a=(0,i.useTranslations)("Process.w3");return(0,b.jsx)("section",{className:"w-full py-4 md:py-20 bg-white",children:(0,b.jsxs)("div",{className:"mx-0 px-0 md:px-0 md:mr-[60px] ",children:[(0,b.jsx)("div",{className:"hidden md:block",children:(0,b.jsxs)("div",{className:"flex flex-row gap-20 md:h-[645px]",children:[(0,b.jsxs)(d.motion.div,{className:"flex-1 relative md:w-[665px]",children:[(0,b.jsxs)("div",{className:"absolute top-0 left-0 w-[392px] h-[493px] z-10",children:[(0,b.jsx)(c.default,{src:"/procesos/3img.webp",alt:"Fibra",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/30"})]}),(0,b.jsx)("div",{className:"absolute bottom-0 right-0 w-[421px] h-[510px] z-20",children:(0,b.jsx)(c.default,{src:"/procesos/4img.webp",alt:"Modelo",fill:!0,className:"object-cover object-[center_20%]"})})]}),(0,b.jsxs)(d.motion.div,{className:"flex-1 flex flex-col justify-start mt-20 ",children:[(0,b.jsx)("h2",{className:`
                  ${f.className}
                  text-[60px] font-thin
                  text-right
                  leading-15
                  tracking-[0.01rem]
                  text-[#C85A3F]
                  mb-0
                  drop-shadow-[0_6px_2px_rgba(0,0,0,0.3)]
                `,children:a("title")}),(0,b.jsx)("h3",{className:`
                  ${f.className}
                  text-[36px] font-extrabold
                  text-right
                  tracking-[0.01rem]
                  text-[#000000]
                  mb-20
                  drop-shadow-[0_3px_1px_rgba(0,0,0,0.3)]
                `,children:a("subtitle")}),(0,b.jsx)("div",{className:"space-y-4 text-black leading-relaxed",children:(0,b.jsx)("p",{className:`${h.className} text-[26px] tracking-normal text-justify leading-7`,children:a("paragraph")})})]})]})}),(0,b.jsxs)("div",{className:"md:hidden",children:[(0,b.jsxs)("div",{className:"flex items-center gap-4 mb-15 px-0",children:[(0,b.jsx)("div",{className:"flex-1 h-px bg-gray-300"}),(0,b.jsx)("h2",{className:`
                ${f.className}
                text-[16px]
                font-thin
                text-[#C85A3F]
                text-center
                whitespace-nowrap
                drop-shadow-[0_8px_2px_rgba(0,0,0,0.3)]
              `,children:a("title")}),(0,b.jsx)("div",{className:"flex-1 h-px bg-gray-300"})]}),(0,b.jsx)("div",{className:"relative z-10 w-12 h-12 mb-0 justify-center flex mx-auto",children:(0,b.jsx)(c.default,{src:"/procesos/llama.svg",alt:"Llama",width:64,height:64,className:"object-contain"})}),(0,b.jsxs)("div",{className:"relative w-full h-[408px] flex flex-col items-center justify-center px-14",children:[(0,b.jsx)("div",{className:"absolute inset-0 z-0",children:(0,b.jsx)(c.default,{src:"/procesos/5img.webp",alt:"Fondo tejido",fill:!0,className:"object-cover"})}),(0,b.jsx)("h3",{className:`
                ${f.className}
                relative z-10
                text-[18px]
                font-extrabold
                tracking-tighter
                text-center
                text-[#000000]
                mt-8
                mb-6
                drop-shadow-[0_2px_2px_rgba(0,0,0,0.3)]
              `,children:a("subtitle")}),(0,b.jsx)("div",{className:"relative z-10 bg-white rounded-3xl px-6 py-8 shadow-lg max-w-md",children:(0,b.jsx)("p",{className:`${h.className} text-[13px] text-black text-justify leading-relaxed`,children:a("paragraph")})})]})]})]})})}a.s(["default",()=>j],43774)},83182,a=>{a.v({className:"jura_441303a2-module__XQxf7W__className"})},83010,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(83182);let f={className:e.default.className,style:{fontFamily:"'Jura', 'Jura Fallback'",fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(15925);function h(){let a=(0,g.useTranslations)("Process.banner");return(0,b.jsxs)("section",{className:"relative w-full h-[230px] md:h-[450px] flex items-center justify-center overflow-hidden",children:[(0,b.jsxs)("div",{className:"absolute inset-0 z-0",children:[(0,b.jsx)(c.default,{src:"/procesos/textil.gif",alt:"Proceso de tejido",fill:!0,className:"object-cover",unoptimized:!0}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/80"})]}),(0,b.jsx)(d.motion.div,{className:"relative z-20 md:z-20 px-6 md:px-12 max-w-4xl mx-auto text-center",children:(0,b.jsx)("h1",{className:`
            ${f.className}
            text-xl md:text-4xl 
            font-medium
            text-[#FFBC8C]
            leading-normal md:leading-relaxed
          `,children:a("title")})})]})}a.s(["default",()=>h],83010)},91630,a=>{a.v({className:"aboreto_4971239d-module__kFZtFW__className"})},21783,a=>{a.v({className:"raleway_164adf74-module__UTI3Lq__className"})},15051,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(91630);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(21783);let h={className:g.default.className,style:{fontFamily:"'Raleway', 'Raleway Fallback'",fontStyle:"normal"}};null!=g.default.variable&&(h.variable=g.default.variable);var i=a.i(15925);function j(){let a=(0,i.useTranslations)("Process.w4");return(0,b.jsx)("section",{className:"w-full py-4 md:py-20 bg-white",children:(0,b.jsxs)("div",{className:"mx-0 px-0",children:[(0,b.jsx)("div",{className:"hidden md:block md:px-0 md:ml-[80px] md:h-[658px]",children:(0,b.jsxs)("div",{className:"flex flex-row gap-20",children:[(0,b.jsxs)(d.motion.div,{className:"w-full md:w-[605px] flex flex-col justify-start mt-20",children:[(0,b.jsx)("h2",{className:`
                  ${f.className}
                  text-[60px] font-thin
                  leading-10
                  tracking-[0.01rem]
                  text-[#C85A3F]
                  mb-20
                  drop-shadow-[0_3px_1px_rgba(0,0,0,0.3)]
                `,children:a("title")}),(0,b.jsx)("div",{className:"space-y-4 text-black leading-relaxed",children:(0,b.jsx)("p",{className:`${h.className} text-[26px] tracking-normal text-justify leading-7`,children:a("paragraph")})})]}),(0,b.jsxs)(d.motion.div,{className:"flex-1 relative h-[655px]",children:[(0,b.jsxs)("div",{className:"absolute top-0 right-0 w-[392px] h-[488px] z-10",children:[(0,b.jsx)(c.default,{src:"/procesos/7img.webp",alt:"Fibra",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/30"})]}),(0,b.jsx)("div",{className:"absolute bottom-0 left-0 w-[421px] h-[510px] z-20",children:(0,b.jsx)(c.default,{src:"/procesos/6img.webp",alt:"Modelo",fill:!0,className:"object-cover object-[center_20%]"})})]})]})}),(0,b.jsxs)("div",{className:"md:hidden",children:[(0,b.jsx)("div",{className:"w-full h-px bg-gray-300 mb-6 "}),(0,b.jsxs)("div",{className:"grid grid-cols-3 gap-0 w-full mb-8",children:[(0,b.jsx)("div",{className:"relative w-full h-[180px]",children:(0,b.jsx)(c.default,{src:"/procesos/4img.webp",alt:"Imagen 1",fill:!0,className:"object-cover"})}),(0,b.jsx)("div",{className:"relative w-full h-[180px]",children:(0,b.jsx)(c.default,{src:"/procesos/6img.webp",alt:"Imagen 2",fill:!0,className:"object-cover"})}),(0,b.jsx)("div",{className:"relative w-full h-[180px]",children:(0,b.jsx)(c.default,{src:"/procesos/7img.webp",alt:"Imagen 3",fill:!0,className:"object-cover"})})]}),(0,b.jsx)("h2",{className:`
              ${f.className}
              text-[15px]
              font-thin
              text-center
              text-[#C85A3F]
              mb-6
              drop-shadow-[0_2px_1px_rgba(0,0,0,0.2)]
            `,children:a("title")}),(0,b.jsx)("p",{className:`
              ${h.className}
              text-[12px]
              text-justify
              text-black
              leading-relaxed
              px-12
            `,children:a("paragraph")})]})]})})}a.s(["default",()=>j],15051)},59218,a=>{a.v({className:"aboreto_b193ed26-module__7BztNq__className"})},86807,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(59218);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(15925);function h(){let a=(0,g.useTranslations)("Process.confection");return(0,b.jsxs)("section",{className:"w-full overflow-x-hidden bg-white mt-10",children:[(0,b.jsx)("div",{className:"relative w-full h-[70px] md:h-[200px]",children:(0,b.jsx)(c.default,{src:"/procesos/8img.webp",alt:"Confección artesanal",fill:!0,className:"object-cover"})}),(0,b.jsx)(d.motion.div,{className:"py-6 md:py-16 px-2 md:px-0",children:(0,b.jsx)("h2",{className:`
            ${f.className}
            text-[14px] md:text-[48px]
            font-thin
            text-center
            text-[#C85A3F]
            drop-shadow-[0_3px_1px_rgba(0,0,0,0.3)]
          `,children:a("title")})})]})}a.s(["default",()=>h],86807)},94472,a=>{a.v({className:"aboreto_7c69aded-module__f_-yjG__className"})},74684,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(94472);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(15925);function h(){let a=(0,g.useTranslations)("Process.w6");return(0,b.jsxs)("section",{className:"relative w-full overflow-hidden",children:[(0,b.jsxs)("div",{className:"grid grid-cols-3 md:gap-0 gap-0 w-full ",children:[(0,b.jsx)("div",{className:"relative w-[100%] h-[190px] md:h-[670px]",children:(0,b.jsx)(c.default,{src:"/procesos/9img.webp",alt:"Equipo trabajando 1",fill:!0,className:"object-cover"})}),(0,b.jsx)("div",{className:"relative w-full h-[190px] md:h-[670px]",children:(0,b.jsx)(c.default,{src:"/procesos/10img.webp",alt:"Equipo trabajando 2",fill:!0,className:"object-cover"})}),(0,b.jsx)("div",{className:"relative w-full h-[190px] md:h-[670px]",children:(0,b.jsx)(c.default,{src:"/procesos/11img.webp",alt:"Equipo trabajando 3",fill:!0,className:"object-cover"})}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/60"})]}),(0,b.jsx)(d.motion.div,{className:"absolute inset-0 z-20 flex items-end justify-center px-2 md:px-30 py-4 md:py-10 opacity-80",children:(0,b.jsx)("p",{className:`
            ${f.className}
            text-[11px] md:text-[32px] 
            font-normal
            text-center
            text-white
            leading-relaxed
          `,children:a("text")})})]})}a.s(["default",()=>h],74684)},39076,a=>{a.v({className:"aboreto_6b0c836f-module__l3C17G__className"})},34788,a=>{"use strict";var b=a.i(87924),c=a.i(71987),d=a.i(46271),e=a.i(39076);let f={className:e.default.className,style:{fontFamily:"'Aboreto', 'Aboreto Fallback'",fontWeight:400,fontStyle:"normal"}};null!=e.default.variable&&(f.variable=e.default.variable);var g=a.i(15925);function h(){let a=(0,g.useTranslations)("Process.w6");return(0,b.jsxs)("section",{className:"w-full overflow-hidden bg-white",children:[(0,b.jsxs)("div",{className:"md:hidden mt-10 mb-10 relative flex flex-row w-full h-[180px]",children:[(0,b.jsx)(d.motion.div,{className:"flex-1 ml-2 flex justify-center items-center shadow-[-20px_0px_10px_rgba(0,0,0,0.2)] ]   ",children:(0,b.jsx)("p",{className:`
              ${f.className}
              text-[12px]
              font-normal
              text-[#BE5103]
              max-w-[125px]
              leading-tight
              drop-shadow-[0_2px_2px_rgba(0,0,0,0.2)]
            `,children:a("text")})}),(0,b.jsxs)("div",{className:"flex-1 relative h-full",children:[(0,b.jsx)(c.default,{src:"/procesos/12img.webp",alt:"Control de calidad",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/30"})]})]}),(0,b.jsxs)("div",{className:"mt-30 mb-60 hidden md:flex md:flex-row md:items-center md:h-[480px]",children:[(0,b.jsx)(d.motion.div,{className:"flex-1 flex items-center justify-start pl-25",children:(0,b.jsx)("p",{className:`
              ${f.className}
              text-[30px]
              font-extrabold
              text-[#BE5103]
              max-w-[560px]
              leading-relaxed
              drop-shadow-[3px_0px_1px_rgba(0,0,0,0.2)]
            `,children:a("text")})}),(0,b.jsxs)("div",{className:"flex-1 relative h-full",children:[(0,b.jsx)(c.default,{src:"/procesos/12img.webp",alt:"Control de calidad",fill:!0,className:"object-cover"}),(0,b.jsx)("div",{className:"absolute inset-0 bg-black/30"})]})]})]})}a.s(["default",()=>h],34788)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__a930f5fd._.js.map
module.exports=[95713,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_libroReclamaciones_page_actions_9f886982.js.map
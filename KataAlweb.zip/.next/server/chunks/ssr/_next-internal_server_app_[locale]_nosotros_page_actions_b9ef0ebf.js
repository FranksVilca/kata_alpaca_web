module.exports=[77649,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_nosotros_page_actions_b9ef0ebf.js.map
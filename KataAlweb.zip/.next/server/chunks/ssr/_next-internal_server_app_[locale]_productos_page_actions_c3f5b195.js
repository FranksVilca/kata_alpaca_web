module.exports=[87589,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_productos_page_actions_c3f5b195.js.map
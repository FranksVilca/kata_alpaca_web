module.exports=[70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},96294,e=>{"use strict";var t=e.i(26747),a=e.i(90406),i=e.i(44898),r=e.i(62950),o=e.i(88712);async function l(e,t){if("POST"!==e.method)return t.status(405).end();let{enterpriseName:a,names:i,email:r,phone:l,message:n}=e.body,s=o.default.createTransport({service:"Gmail",auth:{user:process.env.EMAIL_USER,pass:process.env.EMAIL_PASS}});try{return await s.sendMail({from:process.env.EMAIL_USER,replyTo:r,to:process.env.EMAIL_USER,subject:`🔔 Nuevo Cliente Potencial - ${a}`,html:`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #f4f4f4; }
              .container { max-width: 600px; margin: 20px auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
              .logo-section { background: white; padding: 20px; text-align: center; border-bottom: 3px solid #575151; }
              .logo-section img { max-width: 150px; height: auto; }
              .header { background: linear-gradient(135deg, #F2F2D0 0%, #F2F2D0 100%); color: #575151; padding: 30px; text-align: center; }
              .header h1 { margin: 0; font-size: 24px; }
              .content { background: #f9f9f9; padding: 30px; }
              .field { background: white; margin: 15px 0; padding: 15px; border-radius: 8px; border-left: 4px solid #575151; }
              .field-label { color: #FF8112; font-weight: bold; font-size: 12px; text-transform: uppercase; margin-bottom: 5px; }
              .field-value { color: #333; font-size: 16px; word-break: break-word; }
              .message-box { background: white; padding: 20px; border-radius: 8px; margin-top: 15px; border: 2px solid #575151; }
              .footer { text-align: center; padding: 20px; background: #333; color: white; }
              .footer a { color: #FAF5E8; text-decoration: none; }
              .badge { display: inline-block; background: #4CAF50; color: white; padding: 5px 15px; border-radius: 20px; font-size: 12px; margin-top: 10px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="logo-section">
                <img src="https://www.kataalpaca.com/en/img/logo/logo-kata-alpaca.png" alt="KATA ALPACA Logo">
              </div>
              
              <div class="header">
                <h1>🎉 \xa1Nuevo Cliente Potencial!</h1>
                <div class="badge">FORMULARIO DE CONTACTO</div>
              </div>
              
              <div class="content">
                <div class="field">
                  <div class="field-label">🏢 Empresa</div>
                  <div class="field-value">${a}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">👤 Nombre Completo</div>
                  <div class="field-value">${i}</div>
                </div>
                
                <div class="field">
                  <div class="field-label">📧 Email</div>
                  <div class="field-value"><a href="mailto:${r}" style="color: #575151; text-decoration: none;">${r}</a></div>
                </div>
                
                <div class="field">
                  <div class="field-label">📱 Celular</div>
                  <div class="field-value"><a href="tel:${l}" style="color: #575151; text-decoration: none;">${l}</a></div>
                </div>
                
                <div class="message-box">
                  <div class="field-label">💬 Mensaje</div>
                  <div class="field-value" style="margin-top: 10px; white-space: pre-wrap;">${n}</div>
                </div>
                
                <div style="text-align: center; margin-top: 20px; padding: 15px; background: white; border-radius: 8px;">
                  <p style="color: #666; font-size: 12px; margin: 5px 0;">Recibido el ${new Date().toLocaleString("es-PE",{dateStyle:"full",timeStyle:"short"})}</p>
                </div>
              </div>
              
              <div class="footer">
                <p style="margin: 5px 0;"><strong>KATA ALPACA</strong></p>
                <p style="margin: 5px 0; font-size: 12px;">Este mensaje fue enviado desde el formulario de contacto</p>
                <p style="margin: 5px 0; font-size: 12px;">
                  <a href="mailto:${process.env.EMAIL_USER}">${process.env.EMAIL_USER}</a>
                </p>
              </div>
            </div>
          </body>
        </html>
      `,text:`
        KATA ALPACA - NUEVO CLIENTE POTENCIAL
        
        Empresa: ${a}
        Nombre: ${i}
        Email: ${r}
        Celular: ${l}
        
        Mensaje:
        ${n}
        
        Recibido el ${new Date().toLocaleString("es-PE")}
      `}),t.status(200).json({success:!0})}catch(e){return console.error("Error al enviar correo:",e),t.status(500).json({error:"Error al enviar el correo"})}}e.s(["default",()=>l],72160);var n=e.i(72160),s=e.i(7031),d=e.i(81927),p=e.i(46432);let c=(0,r.hoist)(n,"default"),u=(0,r.hoist)(n,"config"),v=new i.PagesAPIRouteModule({definition:{kind:a.RouteKind.PAGES_API,page:"/api/contacto",pathname:"/api/contacto",bundlePath:"",filename:""},userland:n,distDir:".next",relativeProjectDir:""});async function g(e,a,i){v.isDev&&(0,p.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/contacto";r=r.replace(/\/index$/,"")||"/";let o=await v.prepare(e,a,{srcPage:r});if(!o){a.statusCode=400,a.end("Bad Request"),null==i.waitUntil||i.waitUntil.call(i,Promise.resolve());return}let{query:l,params:n,prerenderManifest:c,routerServerContext:u}=o;try{let t=e.method||"GET",i=(0,s.getTracer)(),o=i.getActiveScopeSpan(),p=v.instrumentationOnRequestError.bind(v),g=async o=>v.render(e,a,{query:{...l,...n},params:n,allowedRevalidateHeaderKeys:[],multiZoneDraftMode:!1,trustHostHeader:!1,previewProps:c.preview,propagateError:!1,dev:v.isDev,page:"/api/contacto",internalRevalidate:null==u?void 0:u.revalidate,onError:(...t)=>p(e,...t)}).finally(()=>{if(!o)return;o.setAttributes({"http.status_code":a.statusCode,"next.rsc":!1});let e=i.getRootSpanAttributes();if(!e)return;if(e.get("next.span_type")!==d.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${e.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let l=e.get("next.route");if(l){let e=`${t} ${l}`;o.setAttributes({"next.route":l,"http.route":l,"next.span_name":e}),o.updateName(e)}else o.updateName(`${t} ${r}`)});o?await g(o):await i.withPropagatedContext(e.headers,()=>i.trace(d.BaseServerSpan.handleRequest,{spanName:`${t} ${r}`,kind:s.SpanKind.SERVER,attributes:{"http.method":t,"http.target":e.url}},g))}catch(e){if(v.isDev)throw e;(0,t.sendError)(a,500,"Internal Server Error")}finally{null==i.waitUntil||i.waitUntil.call(i,Promise.resolve())}}e.s(["config",0,u,"default",0,c,"handler",()=>g],96294)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__0473bd71._.js.map
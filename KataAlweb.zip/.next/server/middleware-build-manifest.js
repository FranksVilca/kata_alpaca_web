globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/eb1ce0af369fe5e1.js",
      "static/chunks/417caf0844d76cd9.js",
      "static/chunks/turbopack-af4fc0ed21d8c041.js"
    ],
    "/_error": [
      "static/chunks/a99462c64ec29197.js",
      "static/chunks/417caf0844d76cd9.js",
      "static/chunks/turbopack-2aade3543a027adc.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/945fab894dcb74b9.js",
    "static/chunks/f8f7457286fb86fb.js",
    "static/chunks/db8f811972a35c8e.js",
    "static/chunks/27c87111c63517f5.js",
    "static/chunks/turbopack-8147f2822c64aeff.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];
var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/contacto.js")
R.c("server/chunks/[root-of-the-server]__0473bd71._.js")
R.c("server/chunks/[root-of-the-server]__0dff3dcf._.js")
R.m(96294)
module.exports=R.m(96294).exports

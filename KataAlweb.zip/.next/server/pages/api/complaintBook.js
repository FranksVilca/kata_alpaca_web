var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/complaintBook.js")
R.c("server/chunks/[root-of-the-server]__711e6622._.js")
R.c("server/chunks/[root-of-the-server]__0dff3dcf._.js")
R.m(10318)
module.exports=R.m(10318).exports

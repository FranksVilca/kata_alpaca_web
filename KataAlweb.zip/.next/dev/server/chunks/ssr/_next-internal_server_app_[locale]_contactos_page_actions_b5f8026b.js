module.exports = [
"[project]/.next-internal/server/app/[locale]/contactos/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_contactos_page_actions_b5f8026b.js.map
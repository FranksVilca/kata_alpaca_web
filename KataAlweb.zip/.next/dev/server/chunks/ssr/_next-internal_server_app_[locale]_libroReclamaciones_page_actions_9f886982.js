module.exports = [
"[project]/.next-internal/server/app/[locale]/libroReclamaciones/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_libroReclamaciones_page_actions_9f886982.js.map
module.exports = [
"[project]/.next-internal/server/app/[locale]/proceso/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_proceso_page_actions_14e013dd.js.map
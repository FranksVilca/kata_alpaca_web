module.exports = [
"[project]/.next-internal/server/app/[locale]/nosotros/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%5Blocale%5D_nosotros_page_actions_b9ef0ebf.js.map
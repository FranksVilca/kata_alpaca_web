self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error",
    "/api/complaintBook",
    "/api/contacto"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()
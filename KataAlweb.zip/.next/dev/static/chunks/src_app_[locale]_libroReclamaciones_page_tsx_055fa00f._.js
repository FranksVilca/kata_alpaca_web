(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[next]_internal_font_google_88d1832d._.css",
  "static/chunks/node_modules_a62142c5._.js",
  "static/chunks/[root-of-the-server]__dc4d2061._.js"
],
    source: "dynamic"
});

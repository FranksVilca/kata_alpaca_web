(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_4b7658f6._.js",
  "static/chunks/[root-of-the-server]__dd1db667._.js",
  "static/chunks/[next]_internal_font_google_c4f32f2e._.css"
],
    source: "dynamic"
});

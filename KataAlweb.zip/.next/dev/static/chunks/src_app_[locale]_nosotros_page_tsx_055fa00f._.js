(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ccf74b75._.js",
  "static/chunks/node_modules_f29578f8._.js",
  "static/chunks/[next]_internal_font_google_4d4622fa._.css"
],
    source: "dynamic"
});

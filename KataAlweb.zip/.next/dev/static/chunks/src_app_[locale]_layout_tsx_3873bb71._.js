(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__db2bda5a._.css",
  "static/chunks/node_modules_f58b4a75._.js"
],
    source: "dynamic"
});

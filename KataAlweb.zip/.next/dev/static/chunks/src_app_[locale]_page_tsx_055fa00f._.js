(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_47ce1889._.js",
  "static/chunks/[root-of-the-server]__3d99d915._.js",
  "static/chunks/[next]_internal_font_google_208d79cb._.css"
],
    source: "dynamic"
});

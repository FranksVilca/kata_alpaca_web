# Kata Alpaca Web

Proyecto web construido con Next.js (App Router) y TypeScript.

## Requisitos
- Node.js 18+ (recomendado 20+)
- npm, yarn, pnpm o bun

## Scripts
- Desarrollo: `npm run dev` (http://localhost:3000)
- Build: `npm run build`
- Previsualización: `npm run start`
- Lint: `npm run lint`

## Estructura del proyecto
- `src/app/` páginas con App Router (ej. `page.tsx`, `nosotros/page.tsx`, etc.)
- `src/components/` componentes compartidos (ej. `header.tsx`, `footer.tsx`)
- `src/styles/` estilos globales y utilidades
- `public/` assets estáticos (imágenes, íconos)

## Desarrollo local
1. Instala dependencias: `npm install`
2. Inicia el servidor de desarrollo: `npm run dev`
3. Abre http://localhost:3000

Para editar la página principal, modifica `src/app/page.tsx`. Los cambios se reflejan automáticamente.

## Fuentes y optimización
El proyecto usa `next/font` y puede integrar la familia Geist de Vercel. Consulta la guía oficial si necesitas personalización avanzada.

- Docs Next.js: https://nextjs.org/docs
- Tutorial interactivo: https://nextjs.org/learn

## Despliegue
La forma más sencilla es desplegar en Vercel.
- Crear cuenta/proyecto en https://vercel.com
- Conectar el repositorio y desplegar

Documentación de despliegue: https://nextjs.org/docs/app/building-your-application/deploying

## Licencia
Este repositorio forma parte del proyecto "kata_alpaca_web". Ajusta esta sección con la licencia que corresponda.